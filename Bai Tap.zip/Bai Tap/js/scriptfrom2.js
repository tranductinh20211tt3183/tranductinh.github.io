const form = document.querySelector('form');
form.onsubmit = (e) => {
  if (form.checkValidity() === false) {
	//Ngăn ko cho form được gửi đi
       e.preventDefault();
       e.stopPropagation()
       }
   form.classList.add('was-validated');
 };
const pass = document.querySelector('.pass')
const repass = document.querySelector('.repass')
pass.onblur = () => {
  repass.setAttribute('pattern',pass.value);
}